package com.example.reddit_fox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
