
class CairoFont {
  static const String black = "Cairo-Black";
  static const String bold = "Cairo-Bold";
  static const String extraLight = "Cairo-ExtraLight";
  static const String extraBold = "Cairo-ExtraBold";
  static const String light = "Cairo-Light";
  static const String medium = "Cairo-Medium";
  static const String regular = "Cairo-Regular";
}
