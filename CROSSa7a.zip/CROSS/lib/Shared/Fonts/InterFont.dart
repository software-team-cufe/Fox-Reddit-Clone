class InterFont {
  static const String black = "Inter-Black";
  static const String bold = "Inter-Bold";
  static const String extraLight = "Inter-ExtraLight";
  static const String extraBold = "Inter-ExtraBold";
  static const String light = "Inter-Light";
  static const String medium = "Inter-Medium";
  static const String regular = "Inter-Regular";
}
