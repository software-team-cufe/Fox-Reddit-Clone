enum ApplicationMode {
  dev,
  run,
}

class Secrets {
  static late final ApplicationMode appMode;
  static const String secretKey = "294dbb212506c814c4765eb954eab1118336a371bc7f57d0ab64cd437f79c2e0";
}
