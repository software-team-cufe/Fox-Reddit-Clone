//import 'dart:html';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:reddit_fox/features/auth/repository/auth_repository.dart';
import 'package:google_sign_in/google_sign_in.dart';

// AuthController authController = AuthController ();
// authController.singInWithGoogle();

// Provider
final authControllerProvider = Provider(
  (ref) => AuthController(
    authRepository: ref.read(authRepositoryProvider),
    ),
  );

class AuthController {
  final AuthRepository _authRepository;
  AuthController({required AuthRepository authRepository}) :_authRepository = authRepository;

  void signInWithGoogle() async {
  final googleSignIn = GoogleSignIn(); // Create an instance of GoogleSignIn
  await googleSignIn.signOut(); // Clear cached account
  _authRepository.signInWithGoogle(); // Call the repository method
}

  }
