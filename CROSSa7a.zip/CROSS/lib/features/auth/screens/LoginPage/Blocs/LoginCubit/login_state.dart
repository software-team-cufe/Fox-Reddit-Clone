part of 'login_cubit.dart';

@immutable
sealed class LoginState {}

class ChangePasswordVisiableState extends LoginState{}
